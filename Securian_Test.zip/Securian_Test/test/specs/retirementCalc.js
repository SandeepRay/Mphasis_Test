import calculateEstimate from '../pageobjects/calculateEstimate.page.js'

describe("Test", () => {

    it("Calculate Estimate with all required fields filled", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 200)
        await calculateEstimate.calcWithReqFields()
        const ele = await $('#results-chart')
        await ele.isDisplayed()
        browser.saveScreenshot("./reqFieldsFinal.png")
    })

    it("Verification of Social Security toggle & Single", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 200)
        await calculateEstimate.calcWithSocialSec()
        const ele = await $('#results-chart')
        await ele.isDisplayed()
        browser.saveScreenshot("./ssnFinal.png")
    })

    it("Verification of Estimate for Married", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 300)
        await calculateEstimate.calcForMarried()
        const ele = await $('#results-chart')
        await ele.isDisplayed()
        browser.saveScreenshot("./marriedOutput.png")
    })

    it("Calculate Estimate with all field filled", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 300)
        await calculateEstimate.calcForAllFields()
        const ele = await $('#results-chart')
        await ele.isDisplayed()
        browser.saveScreenshot("./AllFieldsFinal.png")

    })

    it("Calculate with default calc values", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 300)
        await calculateEstimate.calcWithDefaultValues()
        await browser.pause(5000)
        const ele = await $('#results-chart')
        await ele.isDisplayed()
        browser.saveScreenshot("./defaultValuesFinal.png")
    })


    it("should validate required field errors for no inputs provided", async () => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await browser.scroll(0, 300)
        await calculateEstimate.calculate();
        await browser.pause(3000)
        expect(calculateEstimate.emptyFields_err).toBeDisplayed()
        expect(calculateEstimate.currAgeReq_err).toBeDisplayed()
        expect(calculateEstimate.retAgeReq_err).toBeDisplayed()
        expect(calculateEstimate.currAnnIncomeReq_err).toBeDisplayed()
        expect(calculateEstimate.currRetSavReq).toBeDisplayed()
        expect(calculateEstimate.annSavReq_err).toBeDisplayed()
        expect(calculateEstimate.savIncreaseRateReq_err).toBeDisplayed()

    })

    it("should display correct inline errors for form fields", async() => {
        await browser.url('retirement-calculator.html')
        await browser.maximizeWindow()
        await calculateEstimate.ageZeroValidations()
        await browser.scroll(0, -200)
        browser.saveScreenshot("./inlineErr1.png") 
        expect(calculateEstimate.currAge0_err).toBeDisplayed()
        expect(calculateEstimate.retAge0_err).toBeDisplayed()
        await browser.pause(2000)
        await calculateEstimate.maxAge()
        await browser.scroll(0, -200)
        browser.saveScreenshot("./inlineErr2.png") 
        expect(calculateEstimate.currAgeMax_err).toBeDisplayed()
        expect(calculateEstimate.retAgeMax_err).toBeDisplayed()
        await browser.pause(2000)
        await calculateEstimate.currAgeGreater()
        await browser.scroll(0, -200)
        browser.saveScreenshot("./inlineErr3.png") 
        expect(calculateEstimate.currAgeGreaterThanRet_err).toBeDisplayed()
        await browser.pause(2000)
        await calculateEstimate.defultFieldErrValidation()
        browser.saveScreenshot("./inlineErr4.png") 
        expect(calculateEstimate.retDurationAge0_err).toBeDisplayed()

    })


})