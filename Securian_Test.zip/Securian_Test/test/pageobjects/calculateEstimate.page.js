import testdata from "../testdata/customerdata.js"
import {
    Key
} from 'webdriverio'


class calculateEstimate {

    get currAge() {
        return $("//*[@id='current-age']");
    }
    get retAge() {
        return $("//*[@id='retirement-age']");
    }
    get currAnnIncome() {
        return $("(//label[@for='current-income']/following::input)[1]");
    }
    get spouseIncome() {
        return $("//*[@id='spouse-income']");
    }
    get currRetSav() {
        return $("//*[@id='current-total-savings']");
    }
    get currAnnSavPA() {
        return $("//*[@id='current-annual-savings']");
    }
    get savIncreaseRate() {
        return $("//*[@id='savings-increase-rate']");
    }
    get socSecNumYes_btn() {
        return $("//*[@for='yes-social-benefits']");
    }
    get socSecNumNo_btn() {
        return $("//*[@for='no-social-benefits']");
    }
    get maritalStat_Single_btn() {
        return $("//*[@for='single']");
    }
    get maritalStat_Married_btn() {
        return $("//*[@for='married']");
    }
    get socialSecOverrideAmt() {
        return $("//*[@id='social-security-override']");
    }
    get adjDefValues_link() {
        return $("//*[contains(text(), 'Adjust default values')]");
    }
    get defaultValuesTitle() {
        return $("//*[@id='default-values-modal-title']");
    }
    get otherIncomeInRet() {
        return $("//*[@id='additional-income']");
    }
    get retDuration() {
        return $("//*[@id='retirement-duration']");
    }
    get incInflationYes_btn() {
        return $("//*[@for='include-inflation']");
    }
    get incInflationNo_btn() {
        return $("//*[@for='exclude-inflation']");
    }
    get expInflationRate() {
        return $("//*[@id='expected-inflation-rate']");
    }
    get retAnnIncomeAval() {
        return $("//*[@id='retirement-annual-income']");
    }
    get preRetROI() {
        return $("//*[@id='pre-retirement-roi']");
    }
    get postRetROI() {
        return $("//*[@id='post-retirement-roi']");
    }
    get saveChanges_btn() {
        return $("//*[contains(text(), 'Save changes')]");
    }
    get cancel_btn() {
        return $("//*[contains(text(), 'Cancel')]");
    }
    get calculate_btn() {
        return $("//*[contains(text(), 'Calculate')]");
    }
    get clearForm_btn() {
        return $("//*[contains(text(), 'Clear form')]");
    }

    //Inline Errors

    get emptyFields_err() {
        return $("//*[@id='calculator-input-alert']");
    }
    get currAgeReq_err() {
        return $("//*[@id='invalid-current-age-error']");
    }
    get retAgeReq_err() {
        return $("//*[@id='invalid-retirement-age-error']");
    }
    get currAnnIncomeReq_err() {
        return $("//*[@id='invalid-current-income-error']");
    }
    get currRetSavReq() {
        return $("//*[@id='invalid-current-total-savings-error']");
    }
    get annSavReq_err() {
        return $("//*[@id='invalid-current-annual-savings-error']");
    }
    get savIncreaseRateReq_err() {
        return $("//*[@id='invalid-savings-increase-rate-error']");
    }
    get currAge0_err() {
        return $("//*[@id='invalid-current-age-error' and contains(text(), 'Age cannot be 0')]");
    }
    get retAge0_err() {
        return $("//*[@id='invalid-retirement-age-error' and contains(text(), 'Age cannot be 0')]");
    }
    get currAgeMax_err() {
        return $("//*[@id='invalid-current-age-error' and contains(text(), 'Age cannot be greater than 120')]");
    }
    get retAgeMax_err() {
        return $("//*[@id='invalid-retirement-age-error' and contains(text(), 'Age cannot be greater than 120')]");
    }
    get currAgeGreaterThanRet_err() {
        return $("//*[@id='invalid-retirement-age-error' and contains(text(), 'retirement age must be greater')]");
    }
    get retDurationAge0_err() {
        return $("//*[@id='invalid-retirement-duration-error' and contains(text(), 'Age cannot be 0')]");
    }


    async calcWithReqFields() {
        await this.currAge.setValue(testdata.currentAge)
        await this.retAge.setValue(testdata.retirementAge)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await browser.saveScreenshot("./reqFields.png")
        await this.calculate_btn.click()
        await browser.pause(3000)
    }

    async calcWithSocialSec() {
        await this.currAge.setValue(testdata.currentAge)
        await this.retAge.setValue(testdata.retirementAge)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await this.socSecNumYes_btn.click()
        await browser.pause(2000)
        await this.maritalStat_Single_btn.click()
        await browser.saveScreenshot("./ssnFields.png")
        // await browser.keys(Key.Tab)
        // await browser.keys(Key.Tab)
        //await this.socialSecOverrideAmt.setValue(testdata.socialSecurityAmount)
        await this.calculate_btn.click()
        await browser.pause(3000)
    }

    async calcForMarried() {
        await this.currAge.setValue(testdata.currentAge)
        await this.retAge.setValue(testdata.retirementAge)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await this.socSecNumYes_btn.click()
        await browser.pause(3000)
        await this.maritalStat_Married_btn.click()
        await browser.saveScreenshot("./marriedOptnFields.png")
        //await browser.keys(Key.Tab)
        //await browser.keys(Key.Tab)
        //await this.socialSecOverrideAmt.setValue(testdata.socialSecurityAmount)
        await this.calculate_btn.click()
        await browser.pause(3000)
    }

    async calcForAllFields() {
        await this.currAge.setValue(testdata.currentAge)
        await this.retAge.setValue(testdata.retirementAge)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await this.spouseIncome.setValue(testdata.spouseIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await this.socSecNumYes_btn.click()
        await browser.pause(3000)
        await this.maritalStat_Married_btn.click()
        await browser.saveScreenshot("./marriedOptnFields.png")
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.socialSecOverrideAmt.setValue(testdata.socialSecurityAmount)
        await this.calculate_btn.click()
        await browser.pause(3000)

    }

    async calcWithDefaultValues() {
        await this.currAge.setValue(testdata.currentAge)
        await this.retAge.setValue(testdata.retirementAge)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await this.spouseIncome.setValue(testdata.spouseIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await this.socSecNumYes_btn.click()
        await browser.pause(2000)
        await this.maritalStat_Single_btn.click()
        await browser.keys(Key.Tab)
        await this.socialSecOverrideAmt.setValue(testdata.socialSecurityAmount)
        await this.adjDefValues_link.click()
        const ele = await this.defaultValuesTitle
        await ele.waitForDisplayed({ timeout: 2000 })
        await this.otherIncomeInRet.setValue(testdata.otherIncDuringRetr)
        await this.retDuration.setValue(testdata.retirementDuration)
        await browser.pause(2000)
        await this.incInflationYes_btn.click()
        await browser.pause(2000)
        await this.expInflationRate.setValue(testdata.expectedInflationRate)
        await this.retAnnIncomeAval.setValue(testdata.finalRetirementAmountPA)
        await this.preRetROI.setValue(testdata.preReturn)
        await this.postRetROI.setValue(testdata.postReturn)
        await this.saveChanges_btn.click()
        await browser.saveScreenshot("./defaultValueFields.png")
        await browser.pause(1000)
        await this.calculate_btn.click()
    }

    async calculate() {
        await this.calculate_btn.click()
    }

    async ageZeroValidations() {
        await this.currAge.setValue(testdata.currAge0)
        await this.retAge.setValue(testdata.retAge0)
        await browser.keys(Key.Tab)
        await this.currAnnIncome.setValue(testdata.currentIncome)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await browser.keys(Key.Tab)
        await this.currRetSav.setValue(testdata.currentRetSavBalance)
        await this.currAnnSavPA.setValue(testdata.savPaForRet)
        await this.savIncreaseRate.setValue(testdata.savingsIncreaseRate)
        await this.calculate_btn.click()
    }

    async maxAge() {
        await this.currAge.setValue(testdata.currAgeMax)
        await this.retAge.setValue(testdata.retAgeMax)
        await this.calculate_btn.click()
    }

    async currAgeGreater() {
        await this.currAge.setValue(testdata.currAgeGreaterThanRetAge)
        await this.retAge.setValue(testdata.retAgeLessThanCurrAge)
        await this.calculate_btn.click()
    }

    async defultFieldErrValidation() {
        await this.adjDefValues_link.click()
        await this.retDuration.setValue(testdata.retmDuration0)
        await browser.pause(1000)
        await this.saveChanges_btn.click()
    }

}

export default new calculateEstimate();