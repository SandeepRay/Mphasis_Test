class testdata {

    //Form data
    currentAge= '40'
    retirementAge= '68'
    currentIncome= '100000'
    spouseIncome= '75000'
    currentRetSavBalance= '500000'
    savPaForRet= '10'
    savingsIncreaseRate= '2'
    socialSecurityAmount= '4000'

    //Default Calc values
    otherIncDuringRetr= '500'
    retirementDuration= '20'
    expectedInflationRate= '8'
    finalRetirementAmountPA= '75'
    preReturn= '8'
    postReturn= '5'

    //Error data
    currAge0= '0'
    retAge0= '0'
    currAgeMax= '130'
    retAgeMax= '130'
    currAgeGreaterThanRetAge= '50'
    retAgeLessThanCurrAge= '28'
    retmDuration0 = '0'

}
export default new testdata();